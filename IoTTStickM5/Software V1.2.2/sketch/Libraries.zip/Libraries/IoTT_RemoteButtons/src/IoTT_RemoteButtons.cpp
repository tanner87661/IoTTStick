#include <IoTT_RemoteButtons.h>

uint8_t getButtonTypeByName(String typeName)
{
  if (typeName == "off") return btnTypeOff;
  if (typeName == "digital") return btnTypeDigital;
  if (typeName == "analog") return btnTypeAnalog;
  return btnTypeDigital; //default
}

IoTT_Mux64Buttons::IoTT_Mux64Buttons()
{
	buttonBaton = xSemaphoreCreateMutex();
}

IoTT_Mux64Buttons::~IoTT_Mux64Buttons()
{
    xSemaphoreTake(buttonBaton, portMAX_DELAY);
    xSemaphoreGive(buttonBaton);
    vSemaphoreDelete(buttonBaton);
}

void IoTT_Mux64Buttons::initButtons(uint8_t Addr, uint8_t * analogPins, bool useWifi)
{
	wireAddr = Addr; //
	analogPin = analogPins[0];
	pinMode(analogPin, INPUT);
	numTouchButtons = 16 * analogPins[1]; //byte 1 has number of MUX's served by the 328P at the other end of the wire. byte 0 has the pin number where the signal shows up
	Serial.println(numTouchButtons);
	touchArray = (IoTT_ButtonConfig*) realloc (touchArray, numTouchButtons * sizeof(IoTT_ButtonConfig));
	for (int i = 0; i < numTouchButtons; i++)
	{
		IoTT_ButtonConfig * myTouch = &touchArray[i];
		myTouch->btnTypeRequested = btnTypeDigital; //auto detect	
		myTouch->btnTypeDetected = btnTypeDigital; //auto detect	
		myTouch->btnAddr = boardBaseAddress + i; //LocoNet Button Address

		myTouch->analogDataBuf = 0; //latest reading with scaling applied
		myTouch->analogDiff = 0; //latest reading with scaling applied
		myTouch->analogSigma = 0; //latest reading with scaling applied

		myTouch->analogAvg.setInitValues(); //nitialize with default values
		myTouch->lastPublishedData = 0;
		myTouch->detCtr = 100;
		myTouch->btnStatus = false; //true if pressed
		myTouch->lastStateChgTime[4] = 0; //used to calculate dbl click

		myTouch->nextHoldUpdateTime = millis() + holdThreshold; 
		myTouch->lastEvtPtr = 0;
		myTouch->analogRefreshTime = millis() + analogRefreshInterval;
	}
}

void IoTT_Mux64Buttons::loadButtonCfgJSON(DynamicJsonDocument doc)
{
	if (doc.containsKey("DblClickThreshold"))
		setDblClickRate((int)doc["DblClickThreshold"]);
    if (doc.containsKey("HoldThreshold"))
        setHoldDelay((int)doc["HoldThreshold"]);
    if (doc.containsKey("BoardBaseAddr"))
        setBoardBaseAddr((int)doc["BoardBaseAddr"]);
    if (doc.containsKey("Buttons"))
    {
        JsonArray Buttons = doc["Buttons"];
        uint8_t buttonDefListLen = Buttons.size();
        for (int i=0; i<buttonDefListLen;i++)
        {
			uint8_t thisPort = Buttons[i]["PortNr"];
			if ((thisPort >= 0) && (thisPort < numTouchButtons))
			{
				touchArray[thisPort].btnAddr = Buttons[i]["ButtonAddr"];
				touchArray[thisPort].btnTypeRequested = getButtonTypeByName(Buttons[i]["ButtonType"]);
				touchArray[thisPort].btnTypeDetected = getButtonTypeByName(Buttons[i]["ButtonType"]);
				Serial.printf("Button %i type %i addr %i \n", thisPort, touchArray[thisPort].btnTypeRequested, touchArray[thisPort].btnAddr);
			}
        } 
    }  
}

void IoTT_Mux64Buttons::setButtonMode(uint8_t btnNr, uint8_t btnMode, uint16_t btnAddress)
{
    IoTT_ButtonConfig * thisTouchData = &touchArray[btnNr];
//	Serial.printf("Old Button %i type %i addr %i \n", btnNr, thisTouchData->btnTypeRequested, thisTouchData->btnAddr);
	switch (btnMode)
	{
		case btnoff:
		  thisTouchData->btnTypeRequested = btnTypeOff; 
		  thisTouchData->btnTypeDetected = btnTypeOff;
		  break;
		case digitalAct: 
		  thisTouchData->btnTypeRequested = btnTypeDigital; 
		  thisTouchData->btnTypeDetected =  btnTypeDigital;
		  break;
		case analog:
		  thisTouchData->btnTypeRequested = btnTypeAnalog; 
		  thisTouchData->btnTypeDetected =  btnTypeAnalog;
		  break;
	}
	thisTouchData->btnAddr = btnAddress;
//	Serial.printf("New Button %i type %i addr %i \n", btnNr, thisTouchData->btnTypeRequested, thisTouchData->btnAddr);
}

void IoTT_Mux64Buttons::setDblClickRate(int dblClickRate)
{
	dblClickThreshold = dblClickRate;
}

void IoTT_Mux64Buttons::setHoldDelay(int holdDelay)
{
//	Serial.printf("Set Hold Delay to %i\n", holdDelay);
	holdThreshold = holdDelay;
}

void IoTT_Mux64Buttons::setBoardBaseAddr(int boardAddr)
{
	boardBaseAddress = boardAddr;
	for (int i = 0; i < numTouchButtons; i++)
	{
		IoTT_ButtonConfig * myTouch = &touchArray[i];
		myTouch->btnAddr = boardBaseAddress + i; //set address for all buttons if boardBase changes
	}
}

void IoTT_Mux64Buttons::setAnalogRefreshTime(uint16_t newInterval)
{
	analogRefreshInterval = newInterval;
}

uint8_t  IoTT_Mux64Buttons::getButtonMode(int btnNr)
{
	return touchArray[btnNr].btnTypeRequested;
}

uint16_t  IoTT_Mux64Buttons::getButtonAddress(int btnNr)
{
	return touchArray[btnNr].btnAddr;
}

bool IoTT_Mux64Buttons::getButtonState(int btnNr)
{
	return &touchArray[btnNr].btnStatus;
}

void IoTT_Mux64Buttons::sendButtonEvent(uint16_t btnNr, buttonEvent btnEvent)
{
  IoTT_ButtonConfig * thisTouchData = &touchArray[btnNr];
  if ((onButtonEvent) && (startUpCtr==0)) 
	onButtonEvent(thisTouchData->btnAddr, btnEvent);
  if ((onBtnDiagnose) && (startUpCtr==0)) 
	onBtnDiagnose(0, btnNr, thisTouchData->btnAddr, btnEvent);
}

void IoTT_Mux64Buttons::sendAnalogData(uint8_t btnNr, uint16_t analogValue)
{
  IoTT_ButtonConfig * thisTouchData = &touchArray[btnNr];
  if ((abs(thisTouchData->lastPublishedData - analogValue) > (newAnalogThreshold * analogMaxVal / 100)) || (((analogValue == 0) || (analogValue == analogMaxVal)) && (analogValue != thisTouchData->lastPublishedData)))
  {
	  if (millis() > thisTouchData->nextHoldUpdateTime)
	  {
		  thisTouchData->lastPublishedData = analogValue;
		  if ((onAnalogData) && (startUpCtr==0)) 
			onAnalogData(thisTouchData->btnAddr, analogValue);
  		  if ((onBtnDiagnose) && (startUpCtr==0)) 
			onBtnDiagnose(1, btnNr, thisTouchData->btnAddr, analogValue);
		  thisTouchData->nextHoldUpdateTime = millis() + analogMinMsgDelay;
	  }
  }
}

void IoTT_Mux64Buttons::processDigitalHold(uint8_t btnNr) //call onButtonHold function every holdThreshold milliseconds
{
  IoTT_ButtonConfig * thisTouchData = &touchArray[btnNr];
  if ((thisTouchData->btnStatus) && (millis() > thisTouchData->nextHoldUpdateTime))
  {
	  sendButtonEvent(btnNr, onbtnhold);
	  thisTouchData->nextHoldUpdateTime += holdThreshold;
  }
}

void IoTT_Mux64Buttons::processDigitalButton(uint8_t btnNr, bool btnPressed)
{
//  if (btnNr == 2) Serial.println(btnPressed);
  IoTT_ButtonConfig * thisTouchData = &touchArray[btnNr];
  if (btnPressed != thisTouchData->btnStatus)
  {
	thisTouchData->lastEvtPtr++;
	thisTouchData->lastEvtPtr &= 0x03;
	thisTouchData->lastStateChgTime[thisTouchData->lastEvtPtr] = millis();
	thisTouchData->btnStatus = btnPressed;
//	Serial.println("Button status change");
	if (btnPressed)
	{
//		Serial.println("Button down");
		sendButtonEvent(btnNr, onbtndown);
		thisTouchData->nextHoldUpdateTime = millis() + holdThreshold;
	}
	else
	{
//		Serial.println("Button up");
		sendButtonEvent(btnNr, onbtnup);
		//more processing for click and dblclick
		uint8_t prevUpTime = (thisTouchData->lastEvtPtr + 2) &0x03; //same as mod 4
		if ((thisTouchData->lastStateChgTime[prevUpTime] != 0) && ((thisTouchData->lastStateChgTime[thisTouchData->lastEvtPtr] - thisTouchData->lastStateChgTime[prevUpTime]) < dblClickThreshold))
		{
//		Serial.println("Button Double Click");
			sendButtonEvent(btnNr, onbtndblclick);
		}
		else
		{
//		Serial.println("Button Click");
			sendButtonEvent(btnNr, onbtnclick);
		}
    }
  }
  else
    if (btnPressed)
		processDigitalHold(btnNr);
} 

uint16_t IoTT_Mux64Buttons::readMUXButton(uint8_t inpLineNr, uint8_t muxNr)
{
//	uint16_t newVal = analogRead(analogPin);
	uint8_t newCmd = ((inpLineNr & 0x0F) | (((muxNr ^ 0xFF) & 0x03) << 4));
	//send command to 328P for line and port
	if (newCmd != currentChannel)
	{
//		Serial.printf("Send mux %i Line %i Cmd %x to %i\n", muxNr, inpLineNr, newCmd, wireAddr);
		Wire.beginTransmission(wireAddr);
		Wire.write(newCmd);
		Wire.endTransmission();
		yield();
		currentChannel = newCmd;
	}
	//read analog value on sig input

	uint16_t newVal = analogRead(analogPin);
//	Serial.println(newVal);
	return newVal;
}

uint8_t loopCtr = 0;

void IoTT_Mux64Buttons::processButtons()
{
  byte hlpVal;
  startUpCtr = max(startUpCtr-1,0);
  IoTT_ButtonConfig * thisTouchData;
  uint16_t hlpAnalog;
  uint16_t thisAnalogAvg;
  bool doPrint = false;

  loopCtr++;
  if (loopCtr > 100)
  {
	  doPrint = true;
	  loopCtr = 0;
  }
  else
	doPrint = false;

  for (uint8_t btnCtr = 0; btnCtr < numTouchButtons; btnCtr++)
  {
	thisTouchData = &touchArray[btnCtr];
    int lineNr = btnCtr & 0x0F; //btnCtr % 16;
    int portNr = 0x01 << (btnCtr >> 4); //0x01 << trunc(btnCtr/16);
//    for (uint8_t i = 0; i < numRead; i++)
		thisAnalogAvg = thisTouchData->analogAvg.getEstimate(readMUXButton(lineNr, portNr));
	doPrint = false;
	if ((doPrint) && (btnCtr < 16))
	{
		if ((portNr == 1) && (lineNr == 0))
			Serial.println();
		Serial.print(thisAnalogAvg);
		if ((portNr == 1) && (lineNr == 0))
			loopCtr = 0;
		Serial.print(", ");
	}

	yield();

	  if (thisTouchData->btnTypeRequested != btnTypeOff)
	  {
			if ((thisAnalogAvg >= 0) && (thisAnalogAvg <= analogMaxVal) && ((thisTouchData->btnTypeDetected & btnTypeAnalog) > 0))
				sendAnalogData(btnCtr, thisAnalogAvg);
			else if ((thisAnalogAvg <= digitalLoMax) && ((thisTouchData->btnTypeDetected & btnTypeDigital) > 0))
				processDigitalButton(btnCtr, true);
			else if ((thisAnalogAvg >= digitalHiMin) && ((thisTouchData->btnTypeDetected & btnTypeDigital) > 0))
				processDigitalButton(btnCtr, false);
	  }

  }
}
