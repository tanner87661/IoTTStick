#include <IoTT_LocoNetButtons.h>

buttonEvent getEventTypeFromName(String eventName)
{
//	Serial.print(eventName);
//	Serial.print(" ");
	if (eventName == "onbtndown") return onbtndown;
	if (eventName == "onbtnup") return onbtnup;
	if (eventName == "onbtnclick") return onbtnclick;
	if (eventName == "onbtndblclick") return onbtndblclick;
	if (eventName == "onbtnhold") return onbtnhold;
	return onbtnup; //default

}

actionType getActionTypeByName(String actionName)
{ //blockdet, dccswitch, dccsignal, svbutton, analoginp, powerstat
  if (actionName == "block") return blockdet; 
  if (actionName == "switch") return dccswitch;
  if (actionName == "signal") return dccsignalnmra;
  if (actionName == "button") return svbutton;
  if (actionName == "analog") return analoginp;
  if (actionName == "power") return powerstat;
  return unknown; 
}

ctrlTypeType getCtrlTypeByName(String typeName)
{
  if (typeName == "closed") return closed;
  if (typeName == "thrown") return thrown;
  if (typeName == "toggle") return toggle;
  if (typeName == "nochange") return nochange;
  if (typeName == "input") return input;
  return (ctrlTypeType)typeName.toInt();
}

ctrlValueType getCtrlValueByName(String valueName)
{
  if (valueName == "on") return onVal;
  if (valueName == "off") return offVal;
  if (valueName == "idle") return idleVal;
  return (ctrlValueType)valueName.toInt();
}


/*----------------------------------------------------------------------------------------------------------------------*/

IoTT_BtnHandlerCmd::IoTT_BtnHandlerCmd()
{
//	Serial.println("Obj BtnHdlCmd");
}

IoTT_BtnHandlerCmd::~IoTT_BtnHandlerCmd()
{
}

void IoTT_BtnHandlerCmd::loadButtonCfgJSON(JsonObject thisObj)
{
	targetType = getActionTypeByName(thisObj["CtrlTarget"]);
	targetAddr = thisObj["CtrlAddr"];
	cmdType = getCtrlTypeByName(thisObj["CtrlType"]);
	cmdValue = getCtrlValueByName(thisObj["CtrlValue"]);
	if (thisObj.containsKey("ExecDelay"))
		execDelay = thisObj["ExecDelay"];
	else
		execDelay = 250;
}

void IoTT_BtnHandlerCmd::executeBtnEvent()
{
	Serial.printf("Handling Button Command to Addr %i Type %i Value %i\n", targetAddr, cmdType, cmdValue);
    switch (targetType)
    {
      case dccswitch: if (sendSwitchCommand) sendSwitchCommand(targetAddr, cmdType, cmdValue); break; //switch
      case dccsignalnmra: if (sendSignalCommand) sendSignalCommand(targetAddr, cmdValue); break; //signal
      case powerstat: if (sendPowerCommand) sendPowerCommand(cmdType, cmdValue); break; //analog
      case blockdet: if (sendBlockDetectorCommand) sendBlockDetectorCommand(targetAddr, cmdValue); break; //analog
    }
}


/*----------------------------------------------------------------------------------------------------------------------*/

IoTT_BtnHandler::IoTT_BtnHandler()
{
}

IoTT_BtnHandler::~IoTT_BtnHandler()
{
	for (uint16_t i = 0; i < numCmds; i++)
	{
		IoTT_BtnHandlerCmd * thisPointer = &cmdList[i];
		delete thisPointer;
		thisPointer = NULL;
	}
	numCmds = 0;
	free(cmdList);
}

void IoTT_BtnHandler::loadButtonCfgJSON(JsonObject thisObj)
{
	if (thisObj.containsKey("EventType"))
	{
		eventType = getEventTypeFromName(thisObj["EventType"]);
//		Serial.println(eventType);
	}
	if ((eventType == onbtnhold) || (eventType == onbtndown))
		btnCondAddr = thisObj["BtnCondAddr"];
	if (thisObj.containsKey("CmdList"))
	{
		JsonArray btnCmdList = thisObj["CmdList"];
		numCmds = btnCmdList.size();
		cmdList = (IoTT_BtnHandlerCmd*) realloc (cmdList, numCmds * sizeof(IoTT_BtnHandlerCmd));
		for (uint16_t i = 0; i < numCmds; i++)
		{
			IoTT_BtnHandlerCmd * thisCmd = new(IoTT_BtnHandlerCmd);
			thisCmd->loadButtonCfgJSON(btnCmdList[i]);
			thisCmd->parentObj = this;
			cmdList[i] = *thisCmd;
		}
	}
}

buttonEvent IoTT_BtnHandler::getEventType()
{
	return eventType;
}

uint16_t IoTT_BtnHandler::getCondAddr()
{
	return btnCondAddr;
}

//add command list to buffer for timed execution
//change to allow for merging two lists
void IoTT_BtnHandler::processBtnEvent()
{
	uint32_t lastExecTime = millis();
    cmdBuffer * thisOutBuffer = &parentObj->parentObj->outBuffer;
    //for all lines in the command 
	for (uint16_t i = 0; i < numCmds; i++)
	{
		//find a spot in the buffer
		int nextEmptySlot = -1;
		for (int j = 0; j < cmdBufferLen; j++)
		{
			if (!thisOutBuffer->cmdOutBuffer[j].tbd)
			{
				nextEmptySlot = j;
				break;
			}
		}
		if (nextEmptySlot >= 0) //overwrite protection. If no slot, ignore command
		{
			//place in the buffer
			IoTT_BtnHandlerCmd * thisPointer = &cmdList[i];
			thisOutBuffer->cmdOutBuffer[nextEmptySlot].nextCommand = thisPointer;
			//set the exectime and the tbd flag
			lastExecTime = lastExecTime + thisPointer->execDelay;
			thisOutBuffer->cmdOutBuffer[nextEmptySlot].execTime = lastExecTime;
			thisOutBuffer->cmdOutBuffer[nextEmptySlot].tbd = true;
		}
	}
}


/*----------------------------------------------------------------------------------------------------------------------*/

IoTT_LocoNetButtons::IoTT_LocoNetButtons()
{
}

IoTT_LocoNetButtons::~IoTT_LocoNetButtons()
{
	for (uint16_t i = 0; i < numEvents; i++)
	{
		IoTT_BtnHandler * thisPointer = &eventTypeList[i];
		delete thisPointer;
		thisPointer = NULL;
	}
	numEvents = 0;
	free(eventTypeList);
}

void IoTT_LocoNetButtons::loadButtonCfgJSON(JsonObject thisObj)
{
	if (thisObj.containsKey("ButtonNr"))
		btnAddr = thisObj["ButtonNr"];
	if (thisObj.containsKey("CtrlCmd"))
	{
		JsonArray btnCmd = thisObj["CtrlCmd"];
		numEvents = btnCmd.size();
		
		for (uint16_t i = 0; i < numEvents; i++)
		{
			JsonArray btnCmdList;
			eventTypeList = (IoTT_BtnHandler*) realloc (eventTypeList, numEvents * sizeof(IoTT_BtnHandler));
			IoTT_BtnHandler * thisEvent = new(IoTT_BtnHandler);
			thisEvent->loadButtonCfgJSON(btnCmd[i]);
			thisEvent->parentObj = this;
			eventTypeList[i] = *thisEvent;
		}
	}
}

uint16_t IoTT_LocoNetButtons::getBtnAddr()
{
	return btnAddr;
}

buttonEvent IoTT_LocoNetButtons::getLastRecEvent()
{
	return lastRecButtonEvent;
}

buttonEvent IoTT_LocoNetButtons::getLastComplEvent()
{
	return lastComplButtonEvent;
}

void IoTT_LocoNetButtons::processBtnEvent(buttonEvent inputValue)
{
	if (lastRecButtonEvent != inputValue)
		lastComplButtonEvent = noevent;
	IoTT_BtnHandler * thisEvent = NULL;
	IoTT_LocoNetButtons * secBtn = NULL;
//	Serial.println("processBtn");
	for (uint16_t i = 0; i < numEvents; i++)
	{
		thisEvent = &eventTypeList[i];
		if (thisEvent->getEventType() == inputValue)
		{
//			Serial.printf("process Event %i\n", inputValue);
			if (((inputValue == onbtndown) || (inputValue == onbtnhold))  && (thisEvent->getCondAddr() != 0xFFFF)) //this is 2 hand command for onhold event
			{
//				Serial.printf("2 Btn Command %i\n", thisEvent->getCondAddr());
				//two hand button, check conditions 
				secBtn = parentObj->getButtonByAddress(thisEvent->getCondAddr());
				if (secBtn)
				{
					if ((secBtn->lastRecButtonEvent == onbtnhold) && ((inputValue == onbtnhold) || (inputValue == onbtndown))) //2 hand buttons onhold, current button down or hold
						if ((secBtn->lastComplButtonEvent != onbtnhold) || ((lastComplButtonEvent != onbtnhold) && (lastComplButtonEvent != onbtndown))) //and at least one button cleared
						{
//							Serial.printf("Process Hold Button Event %i\n", inputValue);
							thisEvent->processBtnEvent(); //process event
							lastComplButtonEvent = inputValue;  //set flag on this button
							secBtn->lastComplButtonEvent = inputValue; //set flag on 2 hand button as well, will be cleared in other button when next non-hold event happens
							break; //done
						}
				}
//				else
//					Serial.println("no 2nd button found");
			}
			else //single command, so we process. onhold commands get processed repetitively
			{
				Serial.printf("Process Direct Button Event %i\n", inputValue);
				thisEvent->processBtnEvent();
				lastComplButtonEvent = inputValue; 
			}
			break;
		}
	}
	lastRecButtonEvent = inputValue; //last received event type
}

/*----------------------------------------------------------------------------------------------------------------------*/

IoTT_LocoNetButtonList::IoTT_LocoNetButtonList()
{
}

IoTT_LocoNetButtonList::~IoTT_LocoNetButtonList()
{
	freeObjects();
}

void IoTT_LocoNetButtonList::freeObjects()
{
	for (uint16_t i = 0; i < numBtnHandler; i++)
	{
		IoTT_LocoNetButtons * thisPointer = &btnList[i];
		delete thisPointer;
		thisPointer = NULL;
	}
	numBtnHandler = 0;
	free(btnList);
}

IoTT_LocoNetButtons * IoTT_LocoNetButtonList::getButtonByAddress(uint16_t btnAddr)
{
	for (uint16_t i = 0; i < numBtnHandler; i++)
	{
		IoTT_LocoNetButtons * thisButton = &btnList[i];
		if (thisButton->getBtnAddr() == btnAddr)
		{
			return thisButton;
			break;
		}
	}
	return NULL;
}

uint16_t IoTT_LocoNetButtonList::getButtonIndexByAddress(uint16_t btnAddr, uint16_t startIndex)
{
	for (uint16_t i = startIndex; i < numBtnHandler; i++)
	{
		IoTT_LocoNetButtons * thisButton = &btnList[i];
		if (thisButton->getBtnAddr() == btnAddr)
		{
			return i;
			break;
		}
	}
	return 0xFFFF;
}

void IoTT_LocoNetButtonList::processBtnEvent(uint16_t btnAddr, buttonEvent inputValue)
{
//	Serial.println("Call Handler 1");
	uint16_t lastButton = getButtonIndexByAddress(btnAddr);
	while (lastButton != 0xFFFF) //allow for multiple  button lines with same button Addr
	{
		IoTT_LocoNetButtons * thisButton = &btnList[lastButton];
		if (thisButton)
			thisButton->processBtnEvent(inputValue);
		lastButton = getButtonIndexByAddress(btnAddr, lastButton + 1);
	}
}

void IoTT_LocoNetButtonList::loadButtonCfgJSON(DynamicJsonDocument doc)
{
	if (numBtnHandler > 0)
		freeObjects();
	if (doc.containsKey("ButtonHandler"))
    {
        JsonArray ButtonHandlers = doc["ButtonHandler"];
        numBtnHandler = ButtonHandlers.size();
        btnList = (IoTT_LocoNetButtons*) realloc (btnList, numBtnHandler * sizeof(IoTT_LocoNetButtons));
		for (uint16_t i = 0; i < numBtnHandler; i++)
		{
			IoTT_LocoNetButtons * thisButton = new(IoTT_LocoNetButtons);
			thisButton->loadButtonCfgJSON(ButtonHandlers[i]);
			thisButton->parentObj = this;
			btnList[i] = *thisButton;
		}
	}
}

//buffer with commands for timely execution
//expects execution time and tbd flag set
void IoTT_LocoNetButtonList::processButtonHandler()
{
	int16_t execThis = -1;
	uint32_t lowestExecTime = millis() + 10000; //start with 10 secs time window
	for (int i = 0; i < cmdBufferLen; i++)
	{
		if (outBuffer.cmdOutBuffer[i].tbd)
			if (outBuffer.cmdOutBuffer[i].execTime < lowestExecTime)
			{
				lowestExecTime = outBuffer.cmdOutBuffer[i].execTime;
				execThis = i;
			}
	}
	if (execThis >= 0)
		if (outBuffer.cmdOutBuffer[execThis].execTime <= millis())
		{
			outBuffer.cmdOutBuffer[execThis].nextCommand->executeBtnEvent();
			outBuffer.cmdOutBuffer[execThis].tbd = false;
		}
}

