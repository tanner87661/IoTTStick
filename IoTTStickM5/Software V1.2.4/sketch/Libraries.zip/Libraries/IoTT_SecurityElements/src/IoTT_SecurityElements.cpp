#include <IoTT_SecurityElements.h>

sigAddrType getAddrTypeOfName(String ofName)
{
  if (ofName == "SwiDyn") return swiDyn;
  if (ofName == "SwiStat") return swiStat;
  if (ofName == "SigNMRA") return sigNMRA;
  return sigNMRA;
}

uint8_t getCmdValByName(String ofName)
{
  if (ofName == "closed") return 1;
  if (ofName == "thrown") return 0;
  return ofName.toInt();
}

uint8_t getLegPosFromChar(String ofChar)
{
  if (ofChar == "A") return 0;
  if (ofChar == "B") return 1;
  if (ofChar == "C") return 2;
  return 0xFF;
}

int8_t getCtrlModeByName(String ofName)
{
  if (ofName == "yard") return -1;
  if (ofName == "ABS") return 0;
  if (ofName == "APB") return 2;
  if (ofName == "CTC") return 3;
  return -1;
}

/*----------------------------------------------------------------------------------------------------------------------*/
sigCmdSequence::sigCmdSequence()
{
}

sigCmdSequence::~sigCmdSequence()
{
}

void sigCmdSequence::loadCmdSeqCfgJSON(JsonObject thisObj)
{
	if (thisObj.containsKey("AddrOfs"))
		addrOfs = thisObj["AddrOfs"];
	if (thisObj.containsKey("Cmd"))
		cmdValue = getCmdValByName(thisObj["Cmd"]);
}

/*----------------------------------------------------------------------------------------------------------------------*/
sigAspectDisplay::sigAspectDisplay()
{
}

sigAspectDisplay::~sigAspectDisplay()
{
	freeObjects();
}

void sigAspectDisplay::freeObjects()
{
	if (numSeq > 0)
	{
		for (uint16_t i = 0; i < numSeq; i++)
			delete cmdSeq[i];
		numSeq = 0;
		free(cmdSeq);
	}
}

void sigAspectDisplay::loadAspectDispCfgJSON(JsonObject thisObj)
{
	freeObjects();
	if (thisObj.containsKey("UpToSpeed"))
		upToSpeed = thisObj["UpToSpeed"];
	if (thisObj.containsKey("CmdSeq"))
	{
        JsonArray cmdSeqs = thisObj["CmdSeq"];
        numSeq = cmdSeqs.size();
        cmdSeq = (sigCmdSequence**) realloc (cmdSeq, numSeq * sizeof(sigCmdSequence*));
		for (uint16_t i = 0; i < numSeq; i++)
		{
			sigCmdSequence * thisCmdSeq = new(sigCmdSequence);
			thisCmdSeq->loadCmdSeqCfgJSON(cmdSeqs[i]);
			cmdSeq[i] = thisCmdSeq;
		}
	}
}


/*----------------------------------------------------------------------------------------------------------------------*/
IoTT_SignalTemplate::IoTT_SignalTemplate()
{
//	Serial.println("Create Signal Template");
	
}

IoTT_SignalTemplate::~IoTT_SignalTemplate()
{
	freeObjects();
}

//    {"TemplateName":"Std2Swi", "AddrType":"SwiDyn", "NumAddr":2, "AspectDisplay":[{"UpToSpeed":0, "CmdSeq":[{"AddrOfs": 0, "Cmd":"closed"}]},{"UpToSpeed":30, "CmdSeq":[{"AddrOfs": 0, "Cmd":"thrown"}]}, {"UpToSpeed":60, "CmdSeq":[{"AddrOfs": 1, "Cmd":"closed"}]}, {"UpToSpeed":150, "CmdSeq":[{"AddrOfs": 1, "Cmd":"thrown"}]}]},
void IoTT_SignalTemplate::loadSigTemplCfgJSON(JsonObject thisObj)
{
	freeObjects();
	if (thisObj.containsKey("TemplateName"))
		strcpy(&templName[0], thisObj["TemplateName"]);
	if (thisObj.containsKey("AddrType"))
		addrType = getAddrTypeOfName(thisObj["AddrType"]);
	if (thisObj.containsKey("NumAddr"))
		numAddr = thisObj["NumAddr"];
	if (thisObj.containsKey("AspectDisplay"))
	{
        JsonArray aspectDisps = thisObj["AspectDisplay"];
        numAspects = aspectDisps.size();
        sigAspect = (sigAspectDisplay**) realloc (sigAspect, numAspects * sizeof(sigAspectDisplay*));
		for (uint16_t i = 0; i < numAspects; i++)
		{
			sigAspectDisplay * thisAspect = new(sigAspectDisplay);
			thisAspect->loadAspectDispCfgJSON(aspectDisps[i]);
			sigAspect[i] = thisAspect;
		}
		
	}
}

void IoTT_SignalTemplate::freeObjects()
{
	if (numAspects > 0)
	{
		for (uint16_t i = 0; i < numAspects; i++)
			delete sigAspect[i];
		numAspects = 0;
		free(sigAspect);
	}
}


/*----------------------------------------------------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------------------------------------------------*/
IoTT_SecElLeg::IoTT_SecElLeg()
{
//	Serial.println("Create SecElLeg");
}

IoTT_SecElLeg::~IoTT_SecElLeg()
{
}

void IoTT_SecElLeg::loadSELegCfgJSON(JsonObject thisObj, IoTT_SecurityElement * parent)
{
	parentSE = parent;
	if (thisObj.containsKey("Pos"))
		legPos = getLegPosFromChar(thisObj["Pos"]);
	if (thisObj.containsKey("Speed"))
		legSpeed = thisObj["Speed"];
	if (thisObj.containsKey("DestSE"))
	{
		JsonArray thisDest = thisObj["DestSE"];
		destSENr = thisDest[0];
		destSELeg = getLegPosFromChar(thisDest[1]);
	}
	if (thisObj.containsKey("SigMast"))
	{
		if (thisObj["SigMast"] != -1)
		{
			strcpy(&sigTemplName[0], thisObj["SigMast"]["Templ"]);
			entrySignalAddr = thisObj["SigMast"]["Addr"];
		}
	}
//		IoTT_SecElLeg * destSE;
//		IoTT_SignalTemplate entrySignalTemplate;
	
//	Serial.printf("SE %i Leg %i pointing to SE %i Leg %i\n",parentSE->secelID, legPos, destSENr, destSELeg);
}

void IoTT_SecElLeg::resolveLegConnector(IoTT_SecurityElementList * masterList)
{
//	Serial.printf("Resolve LegConn SecEl %i Dest %i Leg %i ...", parentSE->secelID, destSENr, destSELeg);
	destSE = masterList->getLegPtr(destSENr, destSELeg);
//	if (destSE == NULL)
//	  Serial.println(" failed");
//	else
//	  Serial.println(" successful");
}

void IoTT_SecElLeg::resolveSignalLink(IoTT_SecurityElementList * masterList)
{
	for (uint8_t i = 0; i < masterList->numSigTempl; i++)
		if (strcmp(masterList->sigTemplList[i]->templName, sigTemplName) == 0)
		{
			entrySignalTemplate = masterList->sigTemplList[i];
//			Serial.println("Signal Templ assigned");
			break;
		}
}


uint8_t IoTT_SecElLeg::getLegPos()
{
	return legPos;
}

/*----------------------------------------------------------------------------------------------------------------------*/
IoTT_SecurityElement::IoTT_SecurityElement()
{
}

IoTT_SecurityElement::~IoTT_SecurityElement()
{
	freeObjects();
}

void IoTT_SecurityElement::loadSecElCfgJSON(JsonObject thisObj, IoTT_SecurityElementList * parent)
{
	parentSEL = parent;
	if (thisObj.containsKey("SelID"))
		secelID = thisObj["SelID"];
	if (thisObj.containsKey("CtrlMode"))
		ctrlMode = getCtrlModeByName(thisObj["CtrlMode"]);
	if (thisObj.containsKey("BDAddr"))
		blockdetAddr = thisObj["BDAddr"];
	if (thisObj.containsKey("SwiAddr"))
		switchAddr = thisObj["SwiAddr"];
	if (thisObj.containsKey("SwiLogic"))
		switchLogic = thisObj["SwiLogic"];
	if (thisObj.containsKey("TargetButton"))
		targetBtn = thisObj["TargetButton"];
	if (thisObj.containsKey("DepartureButton"))
		departBtn = thisObj["DepartureButton"];
	if (thisObj.containsKey("IsTerminal"))
		isTerminal = thisObj["IsTerminal"];
	if (thisObj.containsKey("IsStation"))
		isStation = thisObj["IsStation"];
	if (thisObj.containsKey("StationName"))
		strcpy(&stationName[0], thisObj["StationName"]);
	if (thisObj.containsKey("TrackNr"))
		trackNr = thisObj["TrackNr"];
	if (thisObj.containsKey("Connectors"))
	{
        JsonArray seConnectors = thisObj["Connectors"];
        numLegs = seConnectors.size();
        connLeg = (IoTT_SecElLeg**) realloc (connLeg, numLegs * sizeof(IoTT_SecElLeg*));
		for (uint16_t i = 0; i < numLegs; i++)
		{
			IoTT_SecElLeg * thisSELeg = new(IoTT_SecElLeg);
			thisSELeg->loadSELegCfgJSON(seConnectors[i], this);
			connLeg[thisSELeg->getLegPos()] = thisSELeg;
		}
	}
		
}

void IoTT_SecurityElement::resolveLegConnectors(IoTT_SecurityElementList * masterList)
{
	if (numLegs > 0)
		for (uint16_t i = 0; i < numLegs; i++)
		{
			(connLeg[i])->resolveLegConnector(masterList);
			if ((connLeg[i]) == NULL)
				Serial.printf("Allocation of SE %i Leg %i failed\n", secelID, i);
		}
}

void IoTT_SecurityElement::resolveSignalLinks(IoTT_SecurityElementList * masterList)
{
	if (numLegs > 0)
		for (uint16_t i = 0; i < numLegs; i++)
			(connLeg[i])->resolveSignalLink(masterList);
}

IoTT_SecElLeg * IoTT_SecurityElement::getLegPtr(uint8_t destSELeg)
{
	if (destSELeg < numLegs)
		return connLeg[destSELeg];
	else
		return NULL;
}

void IoTT_SecurityElement::processABS()
{
	
}

void IoTT_SecurityElement::clearDirectionFlags()
{
	dirIn = false;
	dirOut = false;
}

void IoTT_SecurityElement::setDirection(bool inBound)
{
	bool currState = inBound ? dirIn : dirOut;
	if (!currState) //if direction is already set, do nothing. Means: Clear directions before setting it
		for (uint16_t i = 0; i < numLegs; i++)
		{
			if (connLeg[i] != NULL)
				if (((i==0) && ((connLeg[i])->destSE->legPos != 0)) || ((i!=0) && ((connLeg[i])->destSE->legPos == 0)))
					(connLeg[i])->parentSE->setDirection(inBound);
				else
					(connLeg[i])->parentSE->setDirection(!inBound);
			
		}
}


void IoTT_SecurityElement::freeObjects()
{
	if (numLegs > 0)
	{
		for (uint16_t i = 0; i < numLegs; i++)
			delete connLeg[i];
		numLegs = 0;
		free(connLeg);
	}
}

/*----------------------------------------------------------------------------------------------------------------------*/
IoTT_SecurityElementList::IoTT_SecurityElementList()
{
}

IoTT_SecurityElementList::~IoTT_SecurityElementList()
{
	freeObjects();
}

void IoTT_SecurityElementList::loadSecElCfgJSON(DynamicJsonDocument doc)
{
	freeObjects();
	if (doc.containsKey("SignalTemplates"))
    {
        JsonArray sigTemplates = doc["SignalTemplates"];
        numSigTempl = sigTemplates.size();
        sigTemplList = (IoTT_SignalTemplate**) realloc (sigTemplList, numSigTempl * sizeof(IoTT_SignalTemplate*));
		for (uint16_t i = 0; i < numSigTempl; i++)
		{
			IoTT_SignalTemplate * thisSigTemplate = new(IoTT_SignalTemplate);
			thisSigTemplate->loadSigTemplCfgJSON(sigTemplates[i]);
			sigTemplList[i] = thisSigTemplate;
		}
	}
	if (doc.containsKey("SecurityElements"))
    {
        JsonArray secEls = doc["SecurityElements"];
        numSecEl = secEls.size();
        secElList = (IoTT_SecurityElement**) realloc (secElList, numSecEl * sizeof(IoTT_SecurityElement*));
		for (uint16_t i = 0; i < numSecEl; i++)
		{
			IoTT_SecurityElement * thisSecElement = new(IoTT_SecurityElement);
			thisSecElement->loadSecElCfgJSON(secEls[i], this);
			secElList[i] = thisSecElement;
		}
	}
	resolveLegConnectors();
	resolveSignalLinks();
}

void IoTT_SecurityElementList::resolveLegConnectors()
{
	for (uint16_t i = 0; i < numSecEl; i++)
	{
		(secElList[i])->resolveLegConnectors(this);
	}
}

void IoTT_SecurityElementList::resolveSignalLinks()
{
	for (uint16_t i = 0; i < numSecEl; i++)
	{
		(secElList[i])->resolveSignalLinks(this);
	}
}

IoTT_SecElLeg * IoTT_SecurityElementList::getLegPtr(uint16_t destSENr, uint8_t destSELeg)
{
	for (uint16_t i = 0; i < numSecEl; i++)
	{
		if ((secElList[i])->secelID == destSENr)
			return (secElList[i])->getLegPtr(destSELeg);
	}
	return NULL;
}

void IoTT_SecurityElementList::processLoop()
{
	for (uint16_t i = 0; i < numSecEl; i++)
		switch ((secElList[i])->ctrlMode)
		{
			case ABS: (secElList[i])->processABS();
		}
	
}

void IoTT_SecurityElementList::clearDirectionFlags()
{
	for (uint16_t i = 0; i < numSecEl; i++)
		(secElList[i])->clearDirectionFlags();
}

void IoTT_SecurityElementList::setDirection(bool inBound)
{
	for (uint16_t i = 0; i < numSecEl; i++)
		(secElList[i])->setDirection(inBound);
}

void IoTT_SecurityElementList::freeObjects()
{
	if (numSecEl > 0)
	{
		for (uint16_t i = 0; i < numSecEl; i++)
			delete secElList[i];
		numSecEl = 0;
		free(secElList);
	}
	if (numSigTempl > 0)
	{
		for (uint16_t i = 0; i < numSigTempl; i++)
			delete sigTemplList[i];
		numSigTempl = 0;
		free(sigTemplList);
	}

}

/*----------------------------------------------------------------------------------------------------------------------*/

