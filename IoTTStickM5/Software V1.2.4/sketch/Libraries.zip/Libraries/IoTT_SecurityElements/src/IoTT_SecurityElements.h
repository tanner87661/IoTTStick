#ifndef IoTT_SecurityElements_h
#define IoTT_SecurityElements_h

#include <Arduino.h>
#include <ArduinoJson.h>
#include <IoTT_DigitraxBuffers.h>

enum sigAddrType : uint8_t  {swiDyn=0, swiStat=1, sigNMRA=3};
enum ctrlType: int8_t {yard=-1, ABS=0, APB=1, CTC=2};

class sigCmdSequence
{
	public:
		sigCmdSequence();
		~sigCmdSequence();
		void loadCmdSeqCfgJSON(JsonObject thisObj);
	private:
	public:
		uint8_t addrOfs = 0;
		uint8_t cmdValue = 0;
};

class sigAspectDisplay
{
	public:
		sigAspectDisplay();
		~sigAspectDisplay();
		void loadAspectDispCfgJSON(JsonObject thisObj);
	private:
		void freeObjects();
	public:
		uint8_t upToSpeed; //in m/s prototype speed
		sigCmdSequence** cmdSeq = NULL;
		uint8_t numSeq = 0;
};

class IoTT_SignalTemplate
{
	public:
		IoTT_SignalTemplate();
		~IoTT_SignalTemplate();
		void loadSigTemplCfgJSON(JsonObject thisObj);
	private:
		void freeObjects();
	public:
		char templName[50] = "";
		sigAddrType addrType = sigNMRA;
		uint8_t numAddr = 1;
		sigAspectDisplay** sigAspect = NULL;
		uint8_t numAspects = 0;
};

class IoTT_SecurityElement; //forward declaration
class IoTT_SecurityElementList;

class IoTT_SecElLeg
{
	public:
		IoTT_SecElLeg();
		~IoTT_SecElLeg();
		void loadSELegCfgJSON(JsonObject thisObj, IoTT_SecurityElement * parent);
		uint8_t getLegPos();
		void resolveLegConnector(IoTT_SecurityElementList * masterList);
		void resolveSignalLink(IoTT_SecurityElementList * masterList);
	private:
	public:
		IoTT_SecurityElement * parentSE = NULL;
		uint8_t legPos;
		uint8_t legSpeed; //m/s prototype speed
		uint16_t destSENr;
		uint8_t destSELeg;
		IoTT_SecElLeg * destSE;
		IoTT_SignalTemplate * entrySignalTemplate;
		uint16_t entrySignalAddr = 0;
		char sigTemplName[50] = "";
};

class IoTT_SecurityElement
{
	public:
		IoTT_SecurityElement();
		~IoTT_SecurityElement();
		void loadSecElCfgJSON(JsonObject thisObj, IoTT_SecurityElementList * parent);
		void resolveLegConnectors(IoTT_SecurityElementList * masterList);
		void resolveSignalLinks(IoTT_SecurityElementList * masterList);
		IoTT_SecElLeg * getLegPtr(uint8_t destSELeg);
		void clearDirectionFlags();
		void setDirection(bool inBound);
		void processABS();
	private:
		void freeObjects();
	
	public:
		uint16_t secelID = 0xFFFF;
		int8_t   ctrlMode = -1;
		uint16_t blockdetAddr = 0xFFFF;
		uint16_t switchAddr = 0xFFFF;
		bool     switchLogic = true; //true = closed=1 -> AB, thrown=0 -> AC and vice versa for false
		uint16_t targetBtn = 0xFFFF;
		uint16_t departBtn = 0xFFFF;
		bool isTerminal = false;
		bool isStation = false;
		char stationName[50] = "";
		uint8_t trackNr = 0;
		IoTT_SecElLeg** connLeg = NULL; //0=A, 1=B, if present, 2=C
		IoTT_SecurityElementList * parentSEL;
		uint8_t numLegs = 0;
	private:
		bool dirIn = false; //from A to B/C
		bool dirOut = false;// from B/C to A
};

class IoTT_SecurityElementList
{
	public:
		IoTT_SecurityElementList();
		~IoTT_SecurityElementList();
		void loadSecElCfgJSON(DynamicJsonDocument doc);
		void resolveLegConnectors();
		void resolveSignalLinks();
		IoTT_SecElLeg * getLegPtr(uint16_t destSENr, uint8_t destSELeg);
		void processLoop();
		void clearDirectionFlags();
		void setDirection(bool inBound);
	private:
		void freeObjects();
		IoTT_SecurityElement** secElList = NULL;
		uint16_t numSecEl = 0;
	public:
		IoTT_SignalTemplate** sigTemplList = NULL;
		uint16_t numSigTempl = 0;
		
};

extern void sendSwitchCommand(uint16_t swiNr, uint8_t swiTargetPos, uint8_t coilStatus) __attribute__ ((weak)); //switch
extern void sendSignalCommand(uint16_t signalNr, uint8_t signalAspect) __attribute__ ((weak)); //signal

#endif
