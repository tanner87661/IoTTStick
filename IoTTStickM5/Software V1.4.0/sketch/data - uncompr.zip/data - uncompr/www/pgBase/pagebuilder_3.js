function tfBtnCommandEditor(y, x, id, evtHandler)
{
	var divElement = document.createElement("div");
	tfSetCoordinate(divElement, y, x, 0, id);
	divElement.setAttribute("class", "cmdedit");
	divElement.append(tfPos(y, x, id, evtHandler));
	var mainDiv = document.createElement("div");
	mainDiv.setAttribute("class", "editortile");
	
	var upperDiv = document.createElement("div");
	upperDiv.setAttribute("class", "editorpanel");
	upperDiv.append(tfManipulatorBox(y, x, id, evtHandler));
	upperDiv.append(tfCmdLineHeader(y, x, id, evtHandler));
	mainDiv.append(upperDiv);
	var lowerDiv = document.createElement("div");
	lowerDiv.setAttribute("class", "editorpanel");
	var hlpDiv = tfEmptyTile(y, x, id, evtHandler);
	hlpDiv.setAttribute("class", "manipulatorbox");
	lowerDiv.append(hlpDiv);
//	lowerDiv.append(tfCmdLineEditor(x, y, id, evtHandler));
	mainDiv.append(lowerDiv);

	divElement.append(mainDiv);

	return divElement;
}

function tfCheckBox(y, x, id, evtHandler)
{
	var textDiv = document.createElement("div");

	var cbElement = document.createElement("input");
	cbElement.setAttribute("type", "checkbox");
	cbElement.setAttribute("id", id);
	cbElement.setAttribute('class', "checkbox");
	cbElement.setAttribute("onclick", evtHandler);
	tfSetCoordinate(cbElement, y, x, 0, id);
	textDiv.append(cbElement);
	
	var textElement = document.createElement("span");
	textElement.setAttribute('id', id + "_cbtxt");
	textElement.setAttribute('class', "checkboxtext");
	textElement.append(document.createTextNode(""));
	textDiv.append(textElement);
	return textDiv;
}

function tfServoEditor(y, x, id, evtHandler)
{
	var divElement = document.createElement("div");
	divElement.setAttribute("class", "servosel");

	var topDiv = document.createElement("div");
	topDiv.setAttribute("class", "servotile");
	divElement.append(topDiv);

	topDiv.append(tfTab(y, x, 'Speed Up: &nbsp;',""));
	thisId = "movespeedup_" + y.toString() + "_" + x.toString();
	var speedUpBox = tfNumeric(y, x, thisId, evtHandler);
	speedUpBox.setAttribute("index", 1);
	topDiv.append(speedUpBox);

	topDiv.append(tfTab(y, x, '&nbsp; Speed Down: &nbsp;',""));
	thisId = "movespeeddown_" + y.toString() + "_" + x.toString();
	var speedDnBox = tfNumeric(y, x, thisId, evtHandler);
	speedDnBox.setAttribute("index", 2);
	topDiv.append(speedDnBox);

	var top2Div = document.createElement("div");
	top2Div.setAttribute("class", "servotile");
	divElement.append(top2Div);

	top2Div.append(tfTab(y, x, 'Accel: &nbsp;',""));
	thisId = "accel_" + y.toString() + "_" + x.toString();
	var speedBox = tfNumeric(y, x, thisId, evtHandler);
	speedBox.setAttribute("index", 3);
	top2Div.append(speedBox);

	top2Div.append(tfTab(y, x, '&nbsp; Decel: &nbsp;',""));
	thisId = "decel_" + y.toString() + "_" + x.toString();
	var speedBox = tfNumeric(y, x, thisId, evtHandler);
	speedBox.setAttribute("index", 4);
	top2Div.append(speedBox);

	var top3Div = document.createElement("div");
	top3Div.setAttribute("class", "servotile");
	divElement.append(top3Div);

	top3Div.append(tfTab(y, x, 'Frequency: &nbsp;',""));
	thisId = "oscfrequ_" + y.toString() + "_" + x.toString();
	var speedBox = tfNumeric(y, x, thisId, evtHandler);
	speedBox.setAttribute("index", 5);
	top3Div.append(speedBox);

	top3Div.append(tfTab(y, x, '&nbsp; Lambda: &nbsp;',""));
	thisId = "lambda_" + y.toString() + "_" + x.toString();
	var speedBox = tfNumeric(y, x, thisId, evtHandler);
	speedBox.setAttribute("index", 6);
	top3Div.append(speedBox);

	var top4Div = document.createElement("div");
	top4Div.setAttribute("class", "servotile");
	divElement.append(top4Div);

	thisId = "hesitate_" + y.toString() + "_" + x.toString();
	var cchBox = tfCheckBox(y, x, thisId, evtHandler);
	cchBox.childNodes[0].setAttribute("index", 7);
	cchBox.childNodes[1].innerHTML = "Hesitation";
	top4Div.append(cchBox);

	top4Div.append(tfTab(y, x, '&nbsp; at &nbsp;',""));
	thisId = "hesipoint_" + y.toString() + "_" + x.toString();
	var hesiBox = tfNumeric(y, x, thisId, evtHandler);
	hesiBox.setAttribute("index", 8);
	top4Div.append(hesiBox);

	top4Div.append(tfTab(y, x, '&nbsp; Min. Speed: &nbsp;',""));
	thisId = "hesispeed_" + y.toString() + "_" + x.toString();
	var hesiBox = tfNumeric(y, x, thisId, evtHandler);
	hesiBox.setAttribute("index", 9);
	top4Div.append(hesiBox);

	var upperDiv = document.createElement("div");
	upperDiv.setAttribute("class", "servotile");
	upperDiv.style.backgroundColor = "#F5F5F5";
	divElement.append(upperDiv);

	thisId = "enableevent_" + y.toString() + "_" + x.toString();
	var cchBox = tfCheckBox(y, x, thisId, evtHandler);
	cchBox.childNodes[0].setAttribute("index", 10);
	cchBox.childNodes[1].innerHTML = "Enable &nbsp;";
	upperDiv.append(cchBox);

/*
	thisId = "positiontext_" + y.toString() + "_" + x.toString();
	var thisText = tfLink(y, x, 0, id, "Position:", evtHandler);
	thisText.setAttribute("index", 11); //high index not causing LED table reload
	upperDiv.append(thisText);
*/
	upperDiv.append(tfTab(y, x, '&nbsp;',""));

	var sliderDiv = document.createElement("div");
	sliderDiv.setAttribute("class", "slidecontainer");
	upperDiv.append(sliderDiv);
	
	thisId = "posslider_" + y.toString() + "_" + x.toString();
	var sliderElement = document.createElement("input");
	sliderElement.setAttribute("type", "range");
	sliderElement.setAttribute("id", thisId);
	sliderElement.setAttribute("min", 200);
	sliderElement.setAttribute("max", 950);
	sliderElement.setAttribute("value", 250);
//	sliderElement.setAttribute('class', "slider");
	sliderElement.setAttribute("oninput", evtHandler);
	tfSetCoordinate(sliderElement, y, x, 12, thisId);
	upperDiv.append(sliderElement);
	upperDiv.append(tfTab(y, x, '&nbsp;',""));

	thisId = "aspectpos_" + y.toString() + "_" + x.toString();
	var posBox = tfNumeric(y, x, thisId, evtHandler);
	posBox.setAttribute("index", 13);
	upperDiv.append(posBox);

	var lowerDiv = document.createElement("div");
	lowerDiv.setAttribute("class", "servotile");
	lowerDiv.style.backgroundColor = "#F5F5F5";
	divElement.append(lowerDiv);
	
	thisId = "softaccel_" + y.toString() + "_" + x.toString();
	var cchBox = tfCheckBox(y, x, thisId, evtHandler);
	cchBox.childNodes[0].setAttribute("index", 14);
	cchBox.childNodes[1].innerHTML = "Soft Start";
	lowerDiv.append(cchBox);

	thisId = "stopmode_" + y.toString() + "_" + x.toString();
	var thisRadio = createRadiobox(lowerDiv, "", "Stop:", ["Hard","Soft","Osc.","Bounce"], thisId, evtHandler);
	var indexCtr = 15;
	for(var i = 0; i < thisRadio.children.length; i++)
	{
		if (thisRadio.children[i].getAttribute("class") == "radiobutton")
		{
			var myId = thisId + "_" + i.toString();
			thisRadio.children[i].setAttribute("row", y.toString());
			thisRadio.children[i].setAttribute("col", x.toString());
			thisRadio.children[i].setAttribute("index", indexCtr.toString());
			indexCtr++;
		}
	}

	tfSetCoordinate(divElement, y, x, 0, id);
	return divElement;
}

function tfButtonEditor(y, x, id, evtHandler)
{
	function createBtnPanel(pIx)
	{
		var panelDiv = document.createElement("div");
		panelDiv.setAttribute("class", "servosel");
		if (pIx > 0)
			panelDiv.style.backgroundColor = "#F5F5F5";
		var upperDiv = document.createElement("div");
		upperDiv.setAttribute("class", "servotile");
		upperDiv.append(tfTab(y, x, "Btn. " + (pIx+1).toString() + ": Addr.:&nbsp;",""));
		panelDiv.append(upperDiv);
		thisId = "btnaddressbox" + pIx.toString() + "_" + y.toString() + "_" + x.toString();
		var addrBox = tfNumeric(y, x, thisId, evtHandler);
		addrBox.setAttribute("index", 5);
		upperDiv.append(addrBox);
		var thisText = tfText(y, x, id, evtHandler);
		thisText.innerHTML = "&nbsp;on:&nbsp;";
		upperDiv.append(thisText);
		thisId = "cmdlistbox" + pIx.toString() + "_" + y.toString() + "_" + x.toString();
		var selBox = tfInpTypeSel(y, x, thisId, evtHandler);
		selBox.setAttribute("index", 6);
		upperDiv.append(selBox);

		var lowerDiv = document.createElement("div");
		lowerDiv.setAttribute("class", "servotile");
		lowerDiv.append(tfTab(y, x, "Send:&nbsp;",""));
		panelDiv.append(lowerDiv);
		thisId = "evttypebox" + pIx.toString() + "_" + y.toString() + "_" + x.toString();
		var typeBox = tfTemplateTypeSel(y, x, thisId, evtHandler);
		createOptions(typeBox, ["Switch","Signal","Block Detector", "Local Only", "none"]);
		typeBox.setAttribute("index", 8);
		lowerDiv.append(typeBox);
		var thisText = tfText(y, x, id, evtHandler);
		thisText.innerHTML = "&nbsp;Addr:&nbsp;";
		lowerDiv.append(thisText);
		thisId = "targetaddressbox" + pIx.toString() + "_" + y.toString() + "_" + x.toString();
		var addrBox = tfNumeric(y, x, thisId, evtHandler);
		addrBox.setAttribute("index", 5);
		lowerDiv.append(addrBox);
		var thisText = tfText(y, x, id, evtHandler);
		thisText.innerHTML = "&nbsp;Event:&nbsp;";
		lowerDiv.append(thisText);
		thisId = "evtvalbox" + pIx.toString() + "_" + y.toString() + "_" + x.toString();
		var typeBox = tfTemplateTypeSel(y, x, thisId, evtHandler);
		typeBox.setAttribute("index", 8);
		lowerDiv.append(typeBox);

		return panelDiv;
	}
	
	var divElement = document.createElement("div");
	divElement.setAttribute("class", "servosel");
	divElement.append(createBtnPanel(0));
	divElement.append(createBtnPanel(1));
	return divElement;
}

function tfLEDEditor(y, x, id, evtHandler)
{
	function createLEDPanel(pIx)
	{
		var panelDiv = document.createElement("div");
		panelDiv.setAttribute("class", "servoledsel");
		if (pIx > 0)
			panelDiv.style.backgroundColor = "#F5F5F5";
		var upperDiv = document.createElement("div");
		upperDiv.setAttribute("class", "servotile");
		panelDiv.append(upperDiv);

		upperDiv.append(tfTab(y, x, "LED " + (pIx+1).toString() + " shows:&nbsp;",""));
		var thisId = "srclistbox" + pIx.toString() + "_" + y.toString() + "_" + x.toString();
		var selBox = tfTemplateTypeSel(y, x, thisId, evtHandler);
		createOptions(selBox, ["Position","Input 1","Input 2"]);
		selBox.setAttribute("index", 6);
		upperDiv.append(selBox);
		upperDiv.append(tfTab(y, x, "&nbsp;when:&nbsp;",""));
		thisId = "evttypebox" + pIx.toString() + "_" + y.toString() + "_" + x.toString();
		var typeBox = tfTemplateTypeSel(y, x, thisId, evtHandler);
		typeBox.setAttribute("index", 8);
		upperDiv.append(typeBox);

		var centerDiv = document.createElement("div");
		centerDiv.setAttribute("class", "servotile");
		panelDiv.append(centerDiv);
		centerDiv.append(tfTab(y, x, "On-Color:&nbsp;",""));
		thisId = "oncolselbox" + pIx.toString() + "_" + y.toString() + "_" + x.toString();
		var oncolselBox = tfTemplateTypeSel(y, x, thisId, evtHandler);
		oncolselBox.setAttribute("index", 8);
		centerDiv.append(oncolselBox);
		centerDiv.append(tfTab(y, x, "&nbsp;Off-Color:&nbsp;",""));
		thisId = "offcolselbox" + pIx.toString() + "_" + y.toString() + "_" + x.toString();
		var offcolselBox = tfTemplateTypeSel(y, x, thisId, evtHandler);
		offcolselBox.setAttribute("index", 8);
		centerDiv.append(offcolselBox);
		
		var lowerDiv = document.createElement("div");
		lowerDiv.setAttribute("class", "servotile");
		panelDiv.append(lowerDiv);
		lowerDiv.append(tfTab(y, x, "Mode:&nbsp;",""));
		thisId = "blinkselectbox" + pIx.toString() + "_" + y.toString() + "_" + x.toString();
		var typeBox = tfTemplateTypeSel(y, x, thisId, evtHandler);
		createOptions(typeBox, ["Static", "Pos Local Blink", "Neg Local Blink", "Pos Global Blink", "Neg Global Blink","Local Rampup", "Local Rampdown","Global Rampup", "Global Rampdown"]);
		typeBox.setAttribute("index", 8);
		lowerDiv.append(typeBox);
		lowerDiv.append(tfTab(y, x, "&nbsp;Rate:&nbsp;",""));
		thisId = "blinkratebox" + pIx.toString() + "_" + y.toString() + "_" + x.toString();
		var timeBox = tfNumeric(y, x, thisId, evtHandler);
		timeBox.setAttribute("index", 5);
		lowerDiv.append(timeBox);
		lowerDiv.append(tfTab(y, x, "&nbsp;Trans.:&nbsp;",""));
		thisId = "transselectbox" + pIx.toString() + "_" + y.toString() + "_" + x.toString();
		var typeBox = tfTemplateTypeSel(y, x, thisId, evtHandler);
		createOptions(typeBox, ["Static", "Direct","Merge"]);
		typeBox.setAttribute("index", 8);
		lowerDiv.append(typeBox);
		return panelDiv;
	}
	
	var divElement = document.createElement("div");
	divElement.setAttribute("class", "servosel");
	divElement.append(createLEDPanel(0));
	divElement.append(createLEDPanel(1));
	return divElement;
}

function tfCommandEditor(y, x, id, evtHandler)
{
	var divElement = document.createElement("div");
	divElement.setAttribute("class", "cmdedit");
	tfSetCoordinate(divElement, y, x, 0, id);
	return divElement;
}

function tfEmptyTile(y, x, id, evtHandler)
{
	var divElement = document.createElement("div");
	divElement.setAttribute("id", id);
	divElement.append(document.createTextNode("xx"));
	return divElement;
}

function createDataTableLines(tableObj, colLoaders, numLines, onchange)
{
	var th = document.getElementById(tableObj.id + "_head");
	var tb = document.getElementById(tableObj.id + "_body");
	var numCols = th.childNodes[0].children.length;
	while (tb.hasChildNodes())
		tb.removeChild(tb.childNodes[0]); //delete rows
	if (numLines > 0)
		for (var i=0; i < numLines; i++)
		{
			var newRow = document.createElement("tr");
			newRow.setAttribute("class", "th");
			tb.append(newRow);
			for (var j=0; j < numCols; j++)
			{
				var thisId = tableObj.id + "_inp_" + i.toString() + "_" + j.toString();
				var newCol = document.createElement("td");
				newCol.setAttribute("id", tableObj.id + "_" + i.toString() + "_" + j.toString());
				newRow.append(newCol);
				var newRB = colLoaders[j](i, j, thisId, onchange);
				newCol.append(newRB);
			}
		}
	else
	{
		var newRow = document.createElement("tr");
		newRow.setAttribute("class", "th");
		tb.append(newRow);
		var thisId = tableObj.id + "_initadd";
		var newCol = document.createElement("td");
		newRow.append(newCol);
		var newRB = tfTableStarterBox(-1, -1, thisId, onchange);
		newCol.append(newRB);
	}
}
