var mainScrollBox;
var switchTable;
var mqttTitle;
var mqttBox;

var swiCfgData = [{},{},{}];
var btnCfgData = [{},{},{}];
var evtHdlrCfgData = [{},{},{}];
var ledData = [{},{},{}];
var colOptions = [];

var subFileIndex = 0;
var updateServoPos = false;

var currDispPage = 0;

var maxButtons = 0;
var numChannels = 16;

var btnStatus = ["off", "digital", "analog"];

var sourceOptionArray = ["switch","dynsignal","dccsignal", "button","analogvalue", "blockdetector", "transponder"];
var newEventTemplate = {"Used": 1, "AspVal": 65535, "PosPt": 270, "MoveCfg": 0};
var newButtonTemplate = {"EventSource":"Button", "ButtonNr": 0,	"CtrlCmd": []};
var newCmdTemplate = {"CtrlTarget": "switch", "CtrlAddr": 0, "CtrlType":"toggle", "CtrlValue":"on", "ExecDelay":250};

var cmdOptions = ["switch", "signal", "block", "local", "none"];
var swiCmdOptions = ["thrown","closed","toggle"];
var blockCmdOptions = ["occupied","free"];

var dispOptions = ["static", "localblinkpos", "localblinkneg", "globalblinkpos", "globalblinkneg","localrampup", "localrampdown","globalrampup", "globalrampdown"]
var transOptions = ["static", "direct","merge"];
function downloadSettings(sender)
{
	downloadConfig(0x0200); //send just this
}

function saveConfigFileSettings()
{
	//step 1: save greenhat.cfg
	saveJSONConfig(scriptList.Pages[currentPage].ID, scriptList.Pages[currentPage].FileName, configData[workCfg], null);
	//then save the other files
	for (var i = 0; i < configData[workCfg].Modules.length; i++)
	{
		saveJSONConfig(configData[workCfg].Modules[i].CfgFiles[0].ID, configData[workCfg].Modules[i].CfgFiles[0].FileName, swiCfgData[workCfg], null);
	}
}

function addFileSeq(ofObj) //object specific function to include partial files
{
//	console.log(ofObj);
}

function prepareFileSeq() //object specific function to create partial files
{
	var objCopy = JSON.parse(JSON.stringify(configData[workCfg]));
	transferData[0].FileList.push(objCopy);
	
/*	
	function addEntry()
	{
		var newEntry = {"ButtonHandler":[]}
		transferData[0].FileList.push(newEntry);
		return newEntry;
	}
	
	var thisEntry = addEntry();
	thisEntry.Version = jsonFileVersion;
	var thisFileLength = 0;
	
	for (var j=0; j<configData[workCfg].ButtonHandler.length;j++)
	{
		var thisElementStr = JSON.stringify(configData[workCfg].ButtonHandler[j]);
		thisFileLength += thisElementStr.length;
		thisEntry.ButtonHandler.push(JSON.parse(thisElementStr));
		if ((thisFileLength > targetSize) && (j < (configData[workCfg].ButtonHandler.length - 1)))
		{
			thisEntry = addEntry();
			thisFileLength = 0;
		}
	}
*/
}

function addDataFile(ofObj)
{
	switch (ofObj.Type)
	{
		case "pgSwitchCfg":
			swiCfgData[loadCfg] = JSON.parse(JSON.stringify(ofObj.Data));
			swiCfgData[workCfg] = upgradeJSONVersionSwitch(JSON.parse(JSON.stringify(swiCfgData[loadCfg])));
//			console.log(swiCfgData[workCfg]);
			break;
		case "pgHWBtnCfg":
			btnCfgData[loadCfg] = JSON.parse(JSON.stringify(ofObj.Data));
			btnCfgData[workCfg] = upgradeJSONVersionBtn(JSON.parse(JSON.stringify(btnCfgData[loadCfg])));
//			console.log(btnCfgData[workCfg]);
			break;
		case "pgBtnHdlrCfg":
			if (evtHdlrCfgData[loadCfg].ButtonHandler == undefined)
				evtHdlrCfgData[loadCfg] = JSON.parse(JSON.stringify(ofObj.Data));
			else
				addFileSeqBtnHdlr(ofObj, evtHdlrCfgData);
			evtHdlrCfgData[workCfg] = upgradeJSONVersionBtnHdlr(JSON.parse(JSON.stringify(evtHdlrCfgData[loadCfg])));
//			console.log(evtHdlrCfgData[workCfg]);
			break;
		case "pgLEDCfg":
			if (ledData[loadCfg].LEDDefs == undefined)
				ledData[loadCfg] = JSON.parse(JSON.stringify(ofObj.Data));
			else
				addFileSeqLED(ofObj, ledData);
			ledData[workCfg] = upgradeJSONVersionLED(JSON.parse(JSON.stringify(ledData[loadCfg])));
//			console.log(ledData[workCfg]);
			break;
	}
	updateServoPos = false;
	loadTableData(switchTable, swiCfgData[workCfg].Drivers, btnCfgData[workCfg].Buttons, evtHdlrCfgData[workCfg].ButtonHandler, ledData[workCfg].LEDDefs);
	updateServoPos = true;
}

function setSwitchData(sender)
{
	var thisRow = parseInt(sender.getAttribute("row"));
	var thisCol = parseInt(sender.getAttribute("col"));
	var thisIndex = parseInt(sender.getAttribute("index"));
//	console.log(thisRow, thisCol, thisIndex);
	switch (thisCol)
	{
		case 1:
			switch (thisIndex)
			{
				case 11: //Event Type
					swiCfgData[workCfg].Drivers[thisRow].CmdSource = sourceOptionArray[sender.selectedIndex];
					adjustSourceSelector(swiCfgData[workCfg].Drivers, thisRow, thisCol);
					break;
				case 12: //Address
					var newRes = verifyNumArray(sender.value, ",");
					var srcMode = sourceOptionArray.indexOf(swiCfgData[workCfg].Drivers[thisRow].CmdSource);
					if ([0,1,5].indexOf(srcMode) >= 0) //limit the length to 3 for stat and dyn signals
						while (newRes.length > 3)
							newRes.pop();
					else
						while (newRes.length > 1) //limit to one for everything else
							newRes.pop();
					swiCfgData[workCfg].Drivers[thisRow].Addr = newRes; //verifyNumber(sender.value, swiCfgData[workCfg].Drivers[thisRow].Addr[0]);
					sender.value = newRes;
					adjustSourceSelector(swiCfgData[workCfg].Drivers, thisRow, thisCol);
					break;
				case 13: //select event
					swiCfgData[workCfg].Drivers[thisRow].CurrDisp = sender.selectedIndex;
					dispSwitchData(swiCfgData[workCfg].Drivers, thisRow);
					setAddr2Disp(sourceOptionArray.indexOf(swiCfgData[workCfg].Drivers[thisRow].CmdSource), sender.selectedIndex, thisRow, thisCol);
					break;
				case 14: //2nd addr
					var srcMode = sourceOptionArray.indexOf(swiCfgData[workCfg].Drivers[thisRow].CmdSource);
					if ([2,4,6].indexOf(srcMode) >= 0) //signal, analog, transponding
					{
						var newRes = verifyNumArray(sender.value, ",");
						if ([2,4].indexOf(srcMode) >= 0) //limit the length to 1 for analog and signal aspects
							while (newRes.length > 1)
								newRes.pop();
						if ([2].indexOf(srcMode) >= 0) //for signals, this is the AspVal
							swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].AspVal = newRes;
						else
							swiCfgData[workCfg].Drivers[thisRow].CondData = newRes;
						sender.value = newRes;
					}
					if (srcMode == 2) //signal
					{
						var sourceList= document.getElementById("cmdlistbox_" + thisRow.toString() + "_" + thisCol.toString());
						if (swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].AspVal != undefined)
							if (swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].AspVal != 0xFFFF)
								sourceList.options[sourceList.selectedIndex].text = "Aspect " + swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].AspVal.toString();
							else
								sourceList.options[sourceList.selectedIndex].text = "Aspect #" + swiCfgData[workCfg].Drivers[thisRow].CurrDisp.toString();
						else
							sourceList.options[sourceList.selectedIndex].text = "Aspect #" + swiCfgData[workCfg].Drivers[thisRow].CurrDisp.toString();
					}
					dispSwitchData(swiCfgData[workCfg].Drivers, thisRow);
					break;
				case 15: //New event
					swiCfgData[workCfg].Drivers[thisRow].Positions.splice(swiCfgData[workCfg].Drivers[thisRow].CurrDisp, 0, JSON.parse(JSON.stringify(newEventTemplate)));
					dispSwitchData(swiCfgData[workCfg].Drivers, thisRow);
					break;
				case 16: //delete event
					if (swiCfgData[workCfg].Drivers[thisRow].Positions.length > 0) //can't delete the last event
					{
						swiCfgData[workCfg].Drivers[thisRow].Positions.splice(swiCfgData[workCfg].Drivers[thisRow].CurrDisp, 1);
						if (swiCfgData[workCfg].Drivers[thisRow].CurrDisp > swiCfgData[workCfg].Drivers[thisRow].Positions.length - 1)
						{
							swiCfgData[workCfg].Drivers[thisRow].CurrDisp = (swiCfgData[workCfg].Drivers[thisRow].Positions.length - 1);
							var evtListBox = document.getElementById("cmdlistbox_" + thisRow.toString() + "_" + thisCol.toString());
							evtListBox.selectedIndex -= 1;
						}
						dispSwitchData(swiCfgData[workCfg].Drivers, thisRow);
//						console.log(swiCfgData[workCfg].Drivers[thisRow]);
					}
					break;
			}
			break;
		case 2:
			switch (thisIndex)
			{
				case 1: //Up Speed
					swiCfgData[workCfg].Drivers[thisRow].UpSpeed = verifyNumber(sender.value, swiCfgData[workCfg].Drivers[thisRow].UpSpeed);
					break;
				case 2: //Down Speed
					swiCfgData[workCfg].Drivers[thisRow].DownSpeed = verifyNumber(sender.value, swiCfgData[workCfg].Drivers[thisRow].DownSpeed);
					break;
				case 3: //Accel Rate
					swiCfgData[workCfg].Drivers[thisRow].AccelRate = verifyNumber(sender.value, swiCfgData[workCfg].Drivers[thisRow].AccelRate);
					break;
				case 4: //Decel rate
					swiCfgData[workCfg].Drivers[thisRow].DecelRate = verifyNumber(sender.value, swiCfgData[workCfg].Drivers[thisRow].DecelRate);
					break;
				case 5: //Frequency
					swiCfgData[workCfg].Drivers[thisRow].Frequency = verifyNumber(sender.value, swiCfgData[workCfg].Drivers[thisRow].Frequency);
					break;
				case 6: //Lambda
					swiCfgData[workCfg].Drivers[thisRow].Lambda = verifyNumber(sender.value, swiCfgData[workCfg].Drivers[thisRow].Lambda);
					break;
				case 7: //use Hesitation
					swiCfgData[workCfg].Drivers[thisRow].UseHesi = sender.checked;
					break;
				case 8: //Hes Point
					swiCfgData[workCfg].Drivers[thisRow].HesPoint = verifyNumber(sender.value, swiCfgData[workCfg].Drivers[thisRow].HesPoint);
					break;
				case 9: //Hes Speed
					swiCfgData[workCfg].Drivers[thisRow].HesSpeed = verifyNumber(sender.value, swiCfgData[workCfg].Drivers[thisRow].HesSpeed);
					break;
				case 10: //use this Aspect
					swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].Used = sender.checked;
					dispSwitchData(swiCfgData[workCfg].Drivers, thisRow);
					break;
				case 12: //Speed slider
					swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].PosPt = sender.value;
					dispSwitchData(swiCfgData[workCfg].Drivers, thisRow);
					break;
				case 13: //Speed input
					swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].PosPt = verifyNumber(sender.value, swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].PosPt);
					dispSwitchData(swiCfgData[workCfg].Drivers, thisRow);
					break;
				case 14: //Soft Start
					if (sender.checked)
						swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].MoveCfg |= 0x04;
					else
						swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].MoveCfg &= (~0x04);
					break;
				case 15: //Hard Stop
					swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].MoveCfg &= (~0x03);
					break;
				case 16: //Soft Stop
					swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].MoveCfg &= (~0x03);
					swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].MoveCfg |= 0x01;
					break;
				case 17: //Oscillate
					swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].MoveCfg &= (~0x03);
					swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].MoveCfg |= 0x02;
					break;
				case 18: //Bounce Back
					swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].MoveCfg |= 0x03;
					break;
			}
			break;
		case 3:
			break;
	}

}

function dispSwitchData(swiData, thisRow)
{
	var evtSrcBox = document.getElementById("evttypebox_" + thisRow.toString() + "_" + "1");
	evtSrcBox.selectedIndex = sourceOptionArray.indexOf(swiData[thisRow].CmdSource);
	var addrBox = document.getElementById("addressbox_" + thisRow.toString() + "_1");
	addrBox.value = swiData[thisRow].Addr;
	console.log(swiData[thisRow].CurrDisp);
	adjustSourceSelector(swiData, thisRow, 1);
	document.getElementById("movespeedup_" + thisRow.toString() + "_" + "2").value = swiData[thisRow].UpSpeed;
	document.getElementById("movespeeddown_" + thisRow.toString() + "_" + "2").value = swiData[thisRow].DownSpeed;
	document.getElementById("accel_" + thisRow.toString() + "_" + "2").value = swiData[thisRow].AccelRate;
	document.getElementById("decel_" + thisRow.toString() + "_" + "2").value = swiData[thisRow].DecelRate;
	document.getElementById("lambda_" + thisRow.toString() + "_" + "2").value = swiData[thisRow].Lambda;
	document.getElementById("oscfrequ_" + thisRow.toString() + "_" + "2").value = swiData[thisRow].Frequency;
	document.getElementById("hesitate_" + thisRow.toString() + "_" + "2").checked = (swiData[thisRow].UseHesi > 0);
	document.getElementById("hesipoint_" + thisRow.toString() + "_" + "2").value = swiData[thisRow].HesPoint;
	document.getElementById("hesispeed_" + thisRow.toString() + "_" + "2").value = swiData[thisRow].HesSpeed;

	document.getElementById("enableevent_" + thisRow.toString() + "_" + "2").checked = swiData[thisRow].Positions[swiData[thisRow].CurrDisp].Used;
	document.getElementById("aspectpos_" + thisRow.toString() + "_" + "2").value = swiData[thisRow].Positions[swiData[thisRow].CurrDisp].PosPt;
	document.getElementById("posslider_" + thisRow.toString() + "_" + "2").value = swiData[thisRow].Positions[swiData[thisRow].CurrDisp].PosPt;
	writeCBInputField("softaccel_" + thisRow.toString()+ "_2", swiData[thisRow].Positions[swiData[thisRow].CurrDisp].MoveCfg & 0x04);
	writeRBInputField("stopmode_" + thisRow.toString() + "_2", swiData[thisRow].Positions[swiData[thisRow].CurrDisp].MoveCfg & 0x03);
	if (updateServoPos)
		if (swiData[thisRow].Positions[swiData[thisRow].CurrDisp].Used)
			setServoPos(thisRow, swiData[thisRow].Positions[swiData[thisRow].CurrDisp].PosPt);
	var enBounce = ((swiData[thisRow].CurrDisp == 0) || (swiData[thisRow].CurrDisp == (swiData[thisRow].Positions.length - 1)));
	setVisibility(enBounce, document.getElementById("stopmode_" + thisRow.toString() + "_" + "2_3"));
	setVisibility(enBounce, document.getElementById("stopmode_" + thisRow.toString() + "_" + "2_tx_3"));
}

function setButtonDisplay(btnData, btnEvtArray, thisRow, thisIndex)
{
	function evtByAddr(hdlrElement)
	{
		return (hdlrElement.ButtonNr == btnData.ButtonAddr);
	}
			
	function loadTargEvtOptions(CtrlCmdData)
	{
		var targetSel = document.getElementById("evttypebox" + thisIndex.toString() + "_" + thisRow.toString() + "_3");
		var targAddrField = document.getElementById("targetaddressbox" + thisIndex.toString() + "_" + thisRow.toString() + "_3");
		var targEvtSel = document.getElementById("evtvalbox" + thisIndex.toString() + "_" + thisRow.toString() + "_3");
		targetSel.selectedIndex = cmdOptions.indexOf(CtrlCmdData.CmdList[0].CtrlTarget);
		targAddrField.value = CtrlCmdData.CmdList[0].CtrlAddr;
		var currCmdOptions = [];
		switch (cmdOptions.indexOf(CtrlCmdData.CmdList[0].CtrlTarget))
		{
			case 0: currCmdOptions = swiCmdOptions; break;
//			case 1: Signal, display aspect field
			case 2: currCmdOptions = blockCmdOptions; break;
			case 3: //local, display options selector
				currCmdOptions = getOptionList("cmdlistbox_" + thisRow.toString() + "_1");
				break;
			case 4: break; //none. Hide everything
		}
		createOptions(targEvtSel, currCmdOptions); 
		if (currCmdOptions != [])
			targEvtSel.selectedIndex = currCmdOptions.indexOf(CtrlCmdData.CmdList[0].CtrlType);
	}
	
	if (btnData)
	{
		if (btnData.currDisp == undefined)
			btnData.currDisp = 0;
		var addrField = document.getElementById("btnaddressbox" + thisIndex.toString() + "_" + thisRow.toString() + "_3");
		addrField.value = btnData.ButtonAddr;
		var evtSel = document.getElementById("cmdlistbox" + thisIndex.toString() + "_" + thisRow.toString() + "_3");
		evtSel.selectedIndex = btnData.currDisp;
		
		if (btnEvtArray)
		{
			var btnHdlrData = btnEvtArray.find(evtByAddr);
			if (btnHdlrData)
				loadTargEvtOptions(btnHdlrData.CtrlCmd[btnData.currDisp]);
		}
	}
}

function setLEDDisplay(ledArray, thisRow, thisIndex)
{
	function ledByPos(ledElement)
	{
		return (ledElement.LEDNums[0] == ledNr) && (ledElement.LEDNums.length == 1);
	}
	
	var ledNr = (2*thisRow) + thisIndex + 1; //calculate LEDNr starting with 1
	var ledData = ledArray.find(ledByPos);
	if (ledData)
	{
		if (ledData.currDisp == undefined)
			ledData.currDisp = 0
		var onColList = document.getElementById("oncolselbox" + thisIndex.toString() + "_" + thisRow.toString() + "_4");
		var offColList = document.getElementById("offcolselbox" + thisIndex.toString() + "_" + thisRow.toString() + "_4");
		var modeList = document.getElementById("blinkselectbox" + thisIndex.toString() + "_" + thisRow.toString() + "_4");
		var rateField = document.getElementById("blinkratebox" + thisIndex.toString() + "_" + thisRow.toString() + "_4");
		var transList = document.getElementById("transselectbox" + thisIndex.toString() + "_" + thisRow.toString() + "_4");
		onColList.selectedIndex = colOptions.indexOf(ledData.LEDCmd[ledData.currDisp].ColOn);
		offColList.selectedIndex = colOptions.indexOf(ledData.LEDCmd[ledData.currDisp].ColOff);
		modeList.selectedIndex = dispOptions.indexOf(ledData.LEDCmd[ledData.currDisp].Mode);
		rateField.value = colOptions.indexOf(ledData.LEDCmd[ledData.currDisp].Rate);
		transList.selectedIndex = transOptions.indexOf(ledData.LEDCmd[ledData.currDisp].Transition);
	}
}

function loadTableData(thisTable, thisSwiData, thisBtnData, thisBtnEvtData, thisLEDData)
{
	var th = document.getElementById(thisTable.id + "_head");
	var tb = document.getElementById(thisTable.id + "_body");
	var numCols = th.childNodes[0].children.length;

	colOptions = [];
	if (thisLEDData)
		for (var j=0; j<ledData[workCfg].LEDCols.length;j++)
			colOptions.push(ledData[workCfg].LEDCols[j].Name);
	
	createDataTableLines(thisTable, [tfPos, tfCommandSwiSelector, tfServoEditor, tfButtonEditor, tfLEDEditor], thisSwiData.length, "setSwitchData(this)");
	for (var thisRow=0; thisRow < numChannels; thisRow++)
	{
		if ((thisSwiData != undefined) && (thisSwiData.length > thisRow))
		{
			if (isNaN(thisSwiData[thisRow].CurrDisp))
				thisSwiData[thisRow].CurrDisp = 0;
			dispSwitchData(thisSwiData, thisRow);
		}
		if ((thisBtnData != undefined) && (thisBtnData.length > (2*thisRow)))
		{
			for (var i=0; i < 2; i++)
				setButtonDisplay(thisBtnData[2*thisRow + i], thisBtnEvtData, thisRow, i);
		}
		if ((thisLEDData != undefined) && (thisLEDData.length > (2*thisRow))) //LEDDefs
		{
			for (var i=0; i<2;i++)
			{
				var onColList = document.getElementById("oncolselbox" + i.toString() + "_" + thisRow.toString() + "_4");
				var offColList = document.getElementById("offcolselbox" + i.toString() + "_" + thisRow.toString() + "_4");
				createOptions(onColList, colOptions);
				createOptions(offColList, colOptions);
				setLEDDisplay(thisLEDData, thisRow, i);
			}
		}
	}
}

function setAddr2Disp(sourceMode, eventMode, thisRow, thisCol)
{
	var addrBox = document.getElementById("parambox_" + thisRow.toString() + "_1");
	var addrField = document.getElementById("address2box_" + thisRow.toString() + "_1");
	var addrText = 	document.getElementById("paramtext_" + thisRow.toString() + "_1");
	var btnAdd = document.getElementById("btn_add_" + thisRow.toString() + "_1");
	var btnCancel = document.getElementById("btn_cancel_" + thisRow.toString() + "_1");
	var srcMode = sourceOptionArray.indexOf(swiCfgData[workCfg].Drivers[thisRow].CmdSource);
	var dispField = false;
	setVisibility(false, btnAdd);
	setVisibility(false, btnCancel);
	switch (sourceMode) //event type
	{
		case 0: //Switch
			break; 
		case 1: //dyn signal
			break;
		case 2: //DCC signal
			dispField = true;  
			setVisibility(true, btnAdd);
			setVisibility(true, btnCancel);
			addrText.innerHTML = "Value:&nbsp;" 
			break; //Signal
		case 3: //button
			break;
		case 4:  //analog
			dispField = [1,2].indexOf(eventMode) >= 0; 
			addrText.innerHTML = "Value:&nbsp;";
			break; //Analog
		case 5: 
			break; //block detector
		case 6: 
			dispField = true;  
			addrText.innerHTML = "Locos:&nbsp;"  //transponder
			break;
	}
	setVisibility(dispField, addrBox);
	if (dispField)
	{
		if ([4,6].indexOf(srcMode) >= 0) //analog, transponder
			if (!Array.isArray(swiCfgData[workCfg].Drivers[thisRow].CondData))
				addrField.value = "";
			else
				addrField.value = swiCfgData[workCfg].Drivers[thisRow].CondData;
		else //dcc signal
			if (isNaN(swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].AspVal))
				addrField.value = "";
			else
				if (swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].AspVal == 0xFFFF)
					addrField.value = "";
				else
					addrField.value = swiCfgData[workCfg].Drivers[thisRow].Positions[swiCfgData[workCfg].Drivers[thisRow].CurrDisp].AspVal;
	}
}

function adjustEventList(ofSwitch, newLength)
{
	while (ofSwitch.Positions.length > newLength) 
		ofSwitch.Positions.splice(ofSwitch.Positions.length-1, 1); //remove last element
	while (ofSwitch.Positions.length < newLength) 
		ofSwitch.Positions.push(JSON.parse(JSON.stringify(newEventTemplate)));
}

function adjustSourceSelector(thisSwiData, thisRow, thisCol)
{
	var evtSrcBox = document.getElementById("evttypebox_" + thisRow.toString() + "_" + thisCol.toString());
	var evtListBox = document.getElementById("cmdlistbox_" + thisRow.toString() + "_" + thisCol.toString());
	evtSrcBox.selectedIndex = sourceOptionArray.indexOf(thisSwiData[thisRow].CmdSource);
	var numAddr = swiCfgData[workCfg].Drivers[thisRow].Addr.length;
	var optArray = [];
	var eventMode = evtListBox.selectedIndex; //get old settings
	//set option strings
	switch (evtSrcBox.selectedIndex)
	{
		case 0: //static switch
			for (var i = 0; i < Math.pow(2, numAddr); i ++)
			{
				var resStr = "";
				for (var p = 0; p < numAddr; p++)
				{
					if (((0x01 << p) & i) > 0)
						resStr += swiCfgData[workCfg].Drivers[thisRow].Addr[p].toString() + " Cl ";
					else
						resStr += swiCfgData[workCfg].Drivers[thisRow].Addr[p].toString() + " Th ";
				}
				optArray.push(resStr);
			}
			createOptions(evtListBox, optArray); 
			break;
		case 1: //signaldyn
			for (var i = 0; i < numAddr; i ++)
			{
				optArray.push(swiCfgData[workCfg].Drivers[thisRow].Addr[i].toString() + " Th");
				optArray.push(swiCfgData[workCfg].Drivers[thisRow].Addr[i].toString() + " Cl");
			}
			createOptions(evtListBox, optArray); 
			break;
		case 2: //DCC Signal
			var aspCnt = thisSwiData[thisRow].Positions.length;
			if (aspCnt > 0)
				for (var i = 0; i < aspCnt; i++)
				{	
					if (thisSwiData[thisRow].Positions[thisSwiData[thisRow].CurrDisp] != undefined)
						if (thisSwiData[thisRow].Positions[i].AspVal != 0xFFFF)
							optArray.push("Aspect " + thisSwiData[thisRow].Positions[i].AspVal.toString());
						else
							optArray.push("Aspect #" + i.toString());
					else
						optArray.push("Aspect #" + i.toString());
				}
			else
				optArray.push("Aspect");
			createOptions(evtListBox, optArray); 
			break; 
		case 3: createOptions(evtListBox, ["Btn Down","Btn Up","Btn Click","Btn Hold", "Btn Dbl Click"]); break; //Button
		case 4: createOptions(evtListBox, [ "== 0", "<", ">=", "== max"]); break; //Analog
		case 5:  //Block detector
			for (var i = 0; i < Math.pow(2, numAddr); i ++)
			{
				var resStr = "";
				for (var p = 0; p < numAddr; p++)
				{
					if (((0x01 << p) & i) > 0)
						resStr += swiCfgData[workCfg].Drivers[thisRow].Addr[p].toString() + " Oc ";
					else
						resStr += swiCfgData[workCfg].Drivers[thisRow].Addr[p].toString() + " Fr ";
				}
				optArray.push(resStr);
			}
			createOptions(evtListBox, optArray); 
			break;
		case 6: createOptions(evtListBox, ["Enter", "Leave"]); break; //Transponder
		case 7: createOptions(evtListBox, ["On", "Off", "Idle"]); break; //power options??
	}
	if (eventMode >= evtListBox.options.length)
		eventMode = 0;
	//adjust length of event list array to new event list
	adjustEventList(thisSwiData[thisRow], evtListBox.options.length);
	//adjust visibility of address box 2
	evtListBox.selectedIndex = eventMode;
	thisSwiData[thisRow].CurrDisp = eventMode;
	setAddr2Disp(evtSrcBox.selectedIndex, eventMode, thisRow, thisCol);
}

function requestDataFiles()
{
	var moduleData = configData[workCfg].Modules[currDispPage];
	ws.send("{\"Cmd\":\"CfgData\", \"Type\":\"" + moduleData.CfgFiles[subFileIndex].ID + "\", \"FileName\":\"" + moduleData.CfgFiles[subFileIndex].FileName+ "\"}");
	subFileIndex++;
	if (subFileIndex < moduleData.CfgFiles.length)
		setTimeout(requestDataFiles, 1500);
}

function constructPageContent(contentTab)
{
	var tempObj;
	mainScrollBox = createEmptyDiv(contentTab, "div", "pagetopicboxscroll-y", "btnconfigdiv");
		createPageTitle(mainScrollBox, "div", "tile-1", "", "h1", "GreenHat Setup");
		createPageTitle(mainScrollBox, "div", "tile-1", "", "h2", "Setup Wizard");
		createPageTitle(mainScrollBox, "div", "tile-1", "", "h2", "Basic Settings");

		switchTable = createDataTable(mainScrollBox, "tile-1", ["Pos","Input Event Selector", "Servo Movement", "Input Setup", "LED Setup"], "swiconfig", "");

		tempObj = createEmptyDiv(mainScrollBox, "div", "tile-1", "");
			createButton(tempObj, "", "Save & Restart", "btnSave", "saveSettings(this)");
			createButton(tempObj, "", "Cancel", "btnCancel", "cancelSettings(this)");
		tempObj = createEmptyDiv(mainScrollBox, "div", "tile-1", "");
			createButton(tempObj, "", "Save to File", "btnDownload", "downloadSettings(this)");
}

function loadNodeDataFields(jsonData)
{
}

function loadDataFields(jsonData)
{
	configData[workCfg] = upgradeJSONVersionGH(jsonData);
	subFileIndex = 0;
	swiCfgData = [{},{},{}];
	btnCfgData = [{},{},{}];
	evtHdlrCfgData = [{},{},{}];
	ledData = [{},{},{}];
	requestDataFiles();
}

function processLocoNetInput(jsonData)
{
}
